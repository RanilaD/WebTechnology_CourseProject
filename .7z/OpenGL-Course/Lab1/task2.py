# Импортируем все необходимые библиотеки:
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *
from math import *

windowTitle = b"Lab1-2"
windowHeight = 600
windowWidth = 600
initWindowX = 50
initWindowY = 50


def draw():
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()
    glColor3f(1, 1, 1)
    draw_circle(0, -0.15, 0.15)
    glColor3f(1, 0, 0.5)
    draw_circle(0, -0.15, 0.4)
    glColor3f(1, 1, 1)
    draw_triangle(0, 0.52, 0.7, 0.36)
    glColor3f(0.55, 0.55, 0.55)
    draw_rect(-0.75, -0.75, 1.5, 1.5)
    glutSwapBuffers()


def init():
    glEnable(GL_DEPTH_TEST)
    glEnable(GL_COLOR_MATERIAL)
    glEnable(GL_LIGHTING)
    glEnable(GL_LIGHT0)
    glLightfv(GL_LIGHT0, GL_POSITION, (0, 0, 1, 0.5))
    glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, (-1, -1, -1))
    glMaterialfv(GL_FRONT, GL_SPECULAR, (1.0, 1.0, 1.0, 1))
    glMaterialf(GL_FRONT, GL_SHININESS, 128.0)
    glLighti(GL_LIGHT0, GL_SPOT_EXPONENT, 0)
    glLighti(GL_LIGHT0, GL_SPOT_CUTOFF, 90)
    glClearColor(1.0, 1.0, 1.0, 1)  # цвет для первоначальной закраски
    glutReshapeFunc(refresh2d)


def refresh2d(width, height):
    glViewport(0, 0, width, height)
    glMatrixMode(GL_PROJECTION)
    glOrtho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0)
    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()


def draw_rect(x, y, width, height):
    glBegin(GL_QUADS)
    glVertex2f(x, y)  # Нижняя левая точка
    glVertex2f(x + width, y)  # Нижняя правая точка
    glVertex2f(x + width, y + height)  # Верхняя правая точка
    glVertex2f(x, y + height)  # Верхняя левая точка
    glEnd()


def draw_triangle(x, y, width, height):
    glBegin(GL_TRIANGLES)
    glVertex2f(x, y + height/2) # верхняя точка
    glVertex2f(x - width/2, y - height/2) # нижняя левая точка
    glVertex2f(x + width/2, y - height/2) # нижняя правая точка
    glEnd()


def draw_circle(x, y, radius):
    glBegin(GL_POLYGON)
    i = 0
    while i <= 2 * pi:
        glVertex3f(x + cos(i)*radius, y + sin(i)*radius, 0)
        i += pi / 64
    glEnd()


glutInit()
glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_ALPHA | GLUT_DEPTH)
glutInitWindowSize(windowWidth, windowHeight)
glutInitWindowPosition(initWindowX, initWindowY)
window = glutCreateWindow(windowTitle)
glutDisplayFunc(draw)
glutIdleFunc(draw)
glutReshapeFunc(refresh2d)
init()
glutMainLoop()