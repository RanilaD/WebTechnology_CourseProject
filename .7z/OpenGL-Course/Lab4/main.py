from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *
from Vase import *


window_width = 800
window_height = 800
global zoom
zoom = 10.0
global x0
global y0
x0 = 0.0
y0 = 0.0
vase = Vase()


def init_glut():
    glutInitWindowSize(window_width, window_height)
    glutInit()
    glutInitDisplayString("samples rgb double depth")
    glutCreateWindow(b"Lab3")
    glutDisplayFunc(render)
    glutIdleFunc(update)
    glutMotionFunc(mouse_move)
    glutKeyboardFunc(key_press)


def init_opengl():
    glClearColor(0.0, 0.0, 0.0, 0.0)
    glEnable(GL_DEPTH_TEST)

    glEnable(GL_COLOR_MATERIAL)
    glEnable(GL_LIGHTING)
    glEnable(GL_LIGHT0)
    glLightfv(GL_LIGHT0, GL_POSITION, (0, 0, 1, 0.5))
    glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, (-1, -1, -1))
    glMaterialfv(GL_FRONT, GL_SPECULAR, (1.0, 1.0, 1.0, 1))
    glMaterialf(GL_FRONT, GL_SHININESS, 128.0)
    glLighti(GL_LIGHT0, GL_SPOT_EXPONENT, 0)
    glLighti(GL_LIGHT0, GL_SPOT_CUTOFF, 90)

    vase.set_texture("texture.jpg")
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)

    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluPerspective(60, window_width / window_height, 0.1, 100)

    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()


def mouse_move(x, y):
    global x0
    global y0
    dx = (x - x0)/5.0
    dy = (y - y0)/5.0
    vase.rotation.y += (dx * pi / 180)
    vase.rotation.x -= (dy * pi / 180)
    x0 = x
    y0 = y


def key_press(key, a, b):
    global zoom
    global x0
    global y0

    if key == b'q':
        zoom *= 1.1
        return
    if key == b'e':
        zoom /= 1.1
        return
    if key == b'a':
        # vase.rotation.y += (2 * pi / 180)
        vase.change_rotation_speed(-1)
        return
    if key == b'd':
        # vase.rotation.y -= (2 * pi / 180)
        vase.change_rotation_speed(1)
        return
    if key == b'w':
        # vase.rotation.x -= (2 * pi / 180)
        vase.change_rotation_axis()
        return
    if key == b's':
        # vase.rotation.x += (2 * pi / 180)
        vase.change_rotation_direction()
        return


def update():
    glutPostRedisplay()


def render():
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()
    gluLookAt(
        zoom * sin(vase.rotation.y),
        zoom * sin(vase.rotation.x),
        zoom * cos(vase.rotation.y),
        0, 0, 0, 0, 1, 0
    )
    vase.draw()
    glutSwapBuffers()


init_glut()
init_opengl()
glutMainLoop()
