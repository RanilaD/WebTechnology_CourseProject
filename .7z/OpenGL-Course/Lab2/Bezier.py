from Vec3f import Vec3f
from math import pow


class Bezier:
    control_points = []

    def __init__(self, control_points):
        self.control_points = control_points

    def make_point(self, t, vec):
        if not isinstance(vec, Vec3f):
            raise NotImplementedError()

        t1 = 1.0 - t
        b = [
            pow(t, 5),
            5 * pow(t, 4) * t1,
            10 * pow(t, 3) * pow(t1, 2),
            10 * pow(t, 2) * pow(t1, 3),
            5 * t * pow(t1, 4),
            pow(t1, 5)
        ]

        for i in range(6):
            vec.x += b[i] * self.control_points[i][0]
            vec.y += b[i] * self.control_points[i][1]
            vec.z += b[i] * self.control_points[i][2]
