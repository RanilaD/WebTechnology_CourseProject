from OpenGL.GLUT import *
from OpenGL.GLU import *
from OpenGL.GL import *

window_width = 500
window_height = 500

def resize(width, height):
    glViewport(0,0,width,height)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    glOrtho(-5,5,-5,5,2,12)
    gluLookAt(0,0,5,0,0,0,0,1,0)
    glMatrixMode(GL_MODELVIEW)


def render():
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
    glPushMatrix()
    glTranslated(0.5,4,0)
    glColor3d(0,0,1)
    glutSolidCube(1)#куб
    glTranslated(0,-2,0)
    glColor3d(0,1,0)
    glutSolidCube(1)#коробка
    glTranslated(0,-2,0)
    glColor3d(0,1,1)
    glutSolidTorus(0.2,0.5,1,5)#тор
    glTranslated(0,-2,0)
    glColor3d(1,0,0)
    glutSolidCylinder(0.5,1, 12, 20)#цилиндр
    glTranslated(0,-2,0)
    glColor3d(0,1,0)
#    glutSolidCone(1,1)#конус
    glTranslated(2,8,0)
    glColor3d(1,0,1)
  #  glutSolidIcosahedron(1)#многогранники
    glTranslated(0,-2,0)
    glColor3d(1,1,1)
    glutSolidOctahedron()
    glTranslated(0,-2,0)
    glColor3d(0,1,1)
    glutSolidTeapot(0.7)#чайник
    glTranslated(0,-2,0)
    glColor3d(0,1,0)
    glutSolidTetrahedron()
    glTranslated(0,-2,0)
    glColor3d(1,1,0)
    glutSolidDodecahedron()
    glTranslated(-6,8,0)
    glColor3d(0,0,1)
    glutWireCube(1)#каркаснаямоделькуба
    glTranslated(0,-2,0)
    glColor3d(0,1,0)
   # glutWireBox(1,0.75,0.5)#каркаснаямодельпараллелограмма
    glTranslated(0,-2,0)
    glColor3d(0,1,1)
#    glutWireTorus(0.2,0.5)#каркаснаямодельтора
    glTranslated(0,-2,0)
    glColor3d(1,0,0)
#    glutWireCylinder(0.5,1)#каркаснаямодельцилиндра
    glTranslated(0,-2,0)
    glColor3d(0,1,0)
  #  glutWireCone(1,1)#каркаснаямодельконуса
    glTranslated(2,8,0)
    glColor3d(1,0,1)
    glutWireIcosahedron()#каркасныемоделимногогранников
    glTranslated(0,-2,0)
    glColor3d(1,1,1)
    glutWireOctahedron()
    glTranslated(0,-2,0)
    glColor3d(0,1,1)
    glutWireTeapot(0.7)#каркаснаямодельчайника
    glTranslated(0,-2,0)
    glColor3d(0,1,0)
    glutWireTetrahedron()
    glTranslated(0,-2,0)
    glColor3d(1,1,0)
    glutWireDodecahedron()
    glPopMatrix()
    glutSwapBuffers()


def init_opengl():
    glEnable(GL_DEPTH_TEST)
    glEnable(GL_COLOR_MATERIAL)
    glEnable(GL_LIGHTING)
    glEnable(GL_LIGHT0)
    glLightfv(GL_LIGHT0, GL_POSITION, (3, 3, 3, 1))
    glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, (-1, -1, -1))


def init_glut():
    glutInitWindowSize(window_width, window_height)
    glutInit()
    glutInitDisplayString("samples rgb double depth")
    glutCreateWindow(b"Lab2")
    glutReshapeFunc(resize)
    glutDisplayFunc(render)
    glutIdleFunc(render)


init_glut()
init_opengl()
glutMainLoop()
