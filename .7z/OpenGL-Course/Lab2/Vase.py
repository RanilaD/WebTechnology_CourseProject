from OpenGL.GL import *
from math import cos
from math import sin
from math import pi
from Bezier import *


class Vase:
    rotation_matrix = [
        [0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0],
    ]
    # опорные точки для построения вазы с помощью кривых Безье
    control_points = [
        [1.25, 3.7, 0.0],
        [0.5, 3.0, 0.0],
        [1.4, 2.4, 0.0],
        [1.8, 2.1, 0.0],
        [1.7, 1.9, 0.0],
        [1.0, -2.0, 0.0]
    ]

    texture = 0

    rotation = Vec3f()
    position = Vec3f(0, 0, 5)
    degree = 20.0
    points_per_curve = 20
    curves_per_surface = 36
    bezier = Bezier(control_points)

    def rotate_matrix(self, angle, vec):
        vec.normalize()

        rad_angle = angle * pi/180.0
        v_cos = cos(rad_angle)
        v_sin = sin(rad_angle)
        iv_cos = 1.0 - v_cos

        self.rotation_matrix[0][0] = vec.x * vec.x * iv_cos + v_cos
        self.rotation_matrix[0][1] = vec.x * vec.y * iv_cos + vec.z * v_sin
        self.rotation_matrix[0][2] = vec.x * vec.z * iv_cos - vec.y * v_sin

        self.rotation_matrix[1][0] = vec.y * vec.x * iv_cos - vec.z * v_sin
        self.rotation_matrix[1][1] = vec.y * vec.y * iv_cos + v_cos
        self.rotation_matrix[1][2] = vec.y * vec.z * iv_cos + vec.x * v_sin

        self.rotation_matrix[2][0] = vec.z * vec.x * iv_cos + vec.y * v_sin
        self.rotation_matrix[2][1] = vec.z * vec.y * iv_cos - vec.x * v_sin
        self.rotation_matrix[2][2] = vec.z * vec.z * iv_cos + v_cos


    def draw(self):
        angle = -360.0 / self.curves_per_surface
        self.rotate_matrix(angle, Vec3f(0.0, 1.0, 0.0))

        current_curves = []
        next_curves = []
        for i in range(self.points_per_curve):
            vec = Vec3f()
            self.bezier.make_point((self.points_per_curve - i - 1) * 1.0 / (self.points_per_curve - 1), vec)
            current_curves.append(vec)
            next_curves.append(Vec3f())

        current_normal = Vec3f()
        next_normal = Vec3f()

        for i in range(self.curves_per_surface):
            # Рисуем сегмент боковой поверхности вазы
            glBegin(GL_TRIANGLE_STRIP)
            for j in range(self.points_per_curve):
                next_curves[j] = current_curves[j].multiply_with_matrix3x3(self.rotation_matrix)
                if j > 0:
                    current_normal.set(current_curves[j] - current_curves[j-1]).normalize()
                    next_normal.set(next_curves[j] - next_curves[j-1]).normalize()
                else:
                    current_normal.set(Vec3f(
                        self.bezier.control_points[1][0] - self.bezier.control_points[0][0],
                        self.bezier.control_points[1][1] - self.bezier.control_points[0][1],
                        self.bezier.control_points[1][2] - self.bezier.control_points[0][2]
                    )).normalize()
                    next_normal.set(current_normal.multiply_with_matrix3x3(self.rotation_matrix)).normalize()

                in_vec = Vec3f(-current_curves[j].x, 0.0, -current_curves[j].z)
                out_vec = current_normal.cross(in_vec)
                current_normal.set(current_normal.cross(out_vec)).normalize()

                in_vec2 = Vec3f(-next_curves[j].x, 0.0, -next_curves[j].z)
                out_vec2 = next_normal.cross(in_vec2)
                next_normal.set(next_normal.cross(out_vec2)).normalize()

                glColor3f(1.0, 1.0, 1.0)
                glNormal3f(current_normal.x, current_normal.y, current_normal.z)
                glVertex3f(current_curves[j].x, current_curves[j].y, current_curves[j].z)

                glColor3f(1.0, 1.0, 1.0)
                glNormal3f(next_normal.x, next_normal.y, next_normal.z)
                glVertex3f(next_curves[j].x, next_curves[j].y, next_curves[j].z)
            glEnd()

            # Рисуем сегмент дна
            glBegin(GL_TRIANGLES)
            glColor3f(1.0, 1.0, 1.0)
            glNormal3f(0.0, -1.0, 0.0)
            glVertex3f(
                next_curves[self.points_per_curve - 1].x,
                next_curves[self.points_per_curve - 1].y,
                next_curves[self.points_per_curve - 1].z
            )

            glColor3f(1.0, 1.0, 1.0)
            glNormal3f(0.0, -1.0, 0.0)
            glVertex3f(0.0, self.bezier.control_points[5][1], 0.0)

            glColor3f(1.0, 1.0, 1.0)
            glNormal3f(0.0, -1.0, 0.0)
            glVertex3f(
                current_curves[self.points_per_curve - 1].x,
                current_curves[self.points_per_curve - 1].y,
                current_curves[self.points_per_curve - 1].z
            )
            glEnd()

            current_curves, next_curves = next_curves, current_curves
            self.rotate_matrix(angle, Vec3f(0.0, 1.0, 0.0))
