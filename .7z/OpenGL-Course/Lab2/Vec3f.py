from math import sqrt
from math import pow


class Vec3f:
    x = 0.0
    y = 0.0
    z = 0.0

    def __init__(self, _x=0.0, _y=0.0, _z=0.0):
        self.x = _x
        self.y = _y
        self.z = _z

    # operator[] set
    def __setitem__(self, key, value):
        if key == 0:
            self.x = value
        elif key == 1:
            self.y = value
        elif key == 2:
            self.z = value
        else:
            raise IndexError("out of bounds")

    # operator[] get
    def __getitem__(self, key):
        if key == 0:
            return self.x
        elif key == 1:
            return self.y
        elif key == 2:
            return self.z
        else:
            raise IndexError("out of bounds")

    def __sub__(self, other):
        if not isinstance(other, Vec3f):
            raise NotImplementedError()
        return Vec3f(self.x - other.x, self.y - other.y, self.z - other.z)

    def __str__(self):
        return f"[{self.x}, {self.y}, {self.z}]"

    def set(self, vec):
        if not isinstance(vec, Vec3f):
            raise NotImplementedError()
        self.x = vec.x
        self.y = vec.y
        self.z = vec.z
        return self

    def length(self):
        return sqrt(pow(self.x, 2) + pow(self.y, 2) + pow(self.z, 2))

    def normalize(self):
        length = self.length()
        if length == 0:
            return
        self.x /= length
        self.y /= length
        self.z /= length

    def cross(self, other):
        return Vec3f(self.y * other.z - self.z * other.y, self.z * other.x - self.x * other.z, self.x * other.y - self.y * other.x)

    def multiply_with_matrix3x3(self, matrix):
        result = Vec3f()
        for i in range(3):
            for j in range(3):
                result[j] += matrix[i][j] * self[i]
        return result
